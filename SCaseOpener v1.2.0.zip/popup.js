const $ = (id) => document.getElementById(id);

// settings
const DELAY_MS = 2200;
const PRESETS = [5, 10, 25, 50, 100, 200]; // quick picks - the box takes any number up to 200
let maxOpens = 5;

let active = false;
let picked = null; // one entry from CASES, or null = current page
const FIRST_CAT = "Weapon cases"; // shown first and selected by default
let catFilter = FIRST_CAT;

// multi-case queue: cases to open in turn, each with its own count. [{id, count}]
let multi = [];
const QUEUE_FRESH_MS = 60 * 1000;
const caseById = (id) => CASES.find((c) => c.id === id);

// Weapon cases first, everything else after (each group keeps its A-Z order).
const SORTED = CASES.slice().sort((a, b) => (b.cat === FIRST_CAT) - (a.cat === FIRST_CAT));

$("ver").textContent = "v" + chrome.runtime.getManifest().version;

const priceNum = (c) => (c ? parseInt(String(c.price).replace(/[^\d]/g, ""), 10) || 0 : 0);
const fmt = (n) => n.toLocaleString("en-US");
function fmtTime(s) {
  s = Math.round(s);
  if (s < 60) return s + "s";
  const m = Math.floor(s / 60);
  return m < 60 ? `${m}m ${s % 60}s` : `${Math.floor(m / 60)}h ${m % 60}m`;
}

function renderCost() {
  const el = $("cost");
  if (!active) $("toggle").textContent = multi.length ? "Start queue" : "Start";
  if (multi.length) {
    const total = multi.reduce((s, m) => s + m.count, 0);
    const coins = multi.reduce((s, m) => s + m.count * priceNum(caseById(m.id)), 0);
    el.innerHTML = `${fmt(total)} opens across ${multi.length} case${multi.length > 1 ? "s" : ""} · <b>${fmt(coins)}</b> coins · about ${fmtTime((total * DELAY_MS) / 1000)}`;
    return;
  }
  const n = maxOpens;
  const secs = fmtTime((n * DELAY_MS) / 1000);
  let html;
  if (!picked) {
    html = `${fmt(n)} opens · pick a case to see the cost <span class="warn">(uses the case on the current page)</span>`;
  } else {
    html = `${fmt(n)} × ${fmt(priceNum(picked))} = <b>${fmt(n * priceNum(picked))}</b> coins · about ${secs}`;
  }
  if (n > 100) html += ' <span class="warn">· over 100</span>';
  el.innerHTML = html;
}

const clampCount = (v) => Math.max(1, Math.min(200, Math.floor(Number(v)) || 1));
const saveMulti = () => chrome.storage.local.set({ multi });

function renderMulti() {
  const box = $("multi");
  box.innerHTML = "";
  if (!multi.length) {
    renderCost();
    return;
  }
  const head = document.createElement("div");
  head.className = "mhead";
  const title = document.createElement("span");
  title.textContent = `Queue · ${multi.length} case${multi.length > 1 ? "s" : ""}`;
  const clear = document.createElement("a");
  clear.textContent = "Clear all";
  clear.onclick = () => { if (active) return; multi = []; saveMulti(); renderMulti(); };
  head.append(title, clear);

  const rows = document.createElement("div");
  rows.className = "mrows";
  multi.forEach((m, i) => {
    const c = caseById(m.id);
    const row = document.createElement("div");
    row.className = "mrow";
    const inp = document.createElement("input");
    inp.type = "number";
    inp.min = 1;
    inp.max = 200;
    inp.step = 1;
    inp.value = m.count;
    inp.title = "Opens for this case (1-200)";
    inp.oninput = () => {
      const n = Math.floor(Number(inp.value));
      if (n >= 1) { m.count = Math.min(200, n); saveMulti(); renderCost(); }
    };
    inp.onblur = () => { m.count = clampCount(inp.value); inp.value = m.count; saveMulti(); renderCost(); };
    const x = document.createElement("button");
    x.className = "x";
    x.textContent = "✕";
    x.title = "Remove from queue";
    x.onclick = () => { if (active) return; multi.splice(i, 1); saveMulti(); renderMulti(); };
    row.append(thumb(c, "thumb"), infoBlock(c), inp, x);
    rows.appendChild(row);
  });
  box.append(head, rows);
  renderCost();
}

$("addQ").onclick = () => {
  if (active) return;
  if (!picked) return setUi(false, "Pick a case first, then add it to the queue");
  multi.push({ id: picked.id, count: clampCount($("count").value) });
  saveMulti();
  renderMulti();
  setUi(false, `Added ${picked.name} · ${multi.length} in the queue`);
};

// runs the queue: the content script opens each case, then moves to the next one
async function startQueue(tab) {
  const items = multi.map((m) => ({ id: m.id, name: caseById(m.id).name, count: m.count }));
  const grand = items.reduce((s, i) => s + i.count, 0);
  const first = `/cases/${items[0].id}`;
  try {
    await chrome.storage.local.set({ queue: { items, index: 0, delayMs: DELAY_MS, t: Date.now() } });
    const here = new URL(tab.url).pathname.replace(/\/$/, "");
    if (here === first) {
      await ensureScript(tab);
      chrome.tabs.sendMessage(tab.id, { type: "queueStart" });
    } else {
      await chrome.tabs.update(tab.id, { url: `https://stridecsgo.net${first}` });
    }
    setUi(true, `Queue · ${items[0].name} 1/${items.length} · starting...`, 0, grand);
  } catch (e) {
    chrome.storage.local.remove("queue");
    setUi(false, "Couldn't reach the page - refresh it and retry");
  }
}function renderPresets() {
  const box = $("presets");
  box.innerHTML = "";
  PRESETS.forEach((n) => {
    const el = document.createElement("span");
    el.className = "pre" + (maxOpens === n ? " on" : "");
    el.textContent = n;
    el.onclick = () => setCount(n);
    box.appendChild(el);
  });
}

function setCount(n) {
  n = Math.max(1, Math.min(200, Math.floor(Number(n)) || 1));
  maxOpens = n;
  $("count").value = n;
  chrome.storage.local.set({ maxOpens: n });
  renderPresets();
  renderCost();
}
$("count").oninput = () => {
  const n = Math.floor(Number($("count").value));
  if (n >= 1) {
    maxOpens = Math.min(200, n);
    chrome.storage.local.set({ maxOpens });
    renderPresets();
    renderCost();
  }
};
$("count").onblur = () => setCount($("count").value);

function setUi(running, text, opened, max) {
  active = running;
  $("toggle").textContent = running ? "Stop" : multi.length ? "Start queue" : "Start";
  $("toggle").classList.toggle("stop", running);
  $("status").textContent = text;
  $("status").classList.toggle("live", running);
  if (typeof opened === "number") $("fill").style.width = Math.min(100, (opened / (max || maxOpens)) * 100) + "%";
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

const onSite = (tab) => tab && /^https:\/\/stridecsgo\.net\//.test(tab.url || "");

async function ensureScript(tab) {
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "ping" });
  } catch (e) {
    // tab was open before the extension loaded, inject manually
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["rarities.js", "content.js"] });
  }
}

function thumb(c, cls) {
  const img = document.createElement("img");
  img.className = cls;
  img.loading = "lazy";
  img.alt = "";
  img.src = IMG_BASE + c.img;
  img.onerror = () => { img.style.visibility = "hidden"; };
  return img;
}

function infoBlock(c) {
  const info = document.createElement("div");
  info.className = "info";
  info.innerHTML = '<div class="name"></div><div class="type"></div>';
  info.firstChild.textContent = c.name;
  info.lastChild.textContent = c.cat;
  return info;
}

function priceBlock(c) {
  const p = document.createElement("div");
  p.className = "price";
  p.textContent = c.price;
  return p;
}

// chips
function renderChips() {
  const counts = {};
  CASES.forEach((c) => (counts[c.cat] = (counts[c.cat] || 0) + 1));
  const cats = Object.keys(counts)
    .filter((c) => c !== FIRST_CAT)
    .sort((a, b) => counts[b] - counts[a]);
  const box = $("chips");
  box.innerHTML = "";
  [[FIRST_CAT, FIRST_CAT, counts[FIRST_CAT] || 0], ["", "All", CASES.length], ...cats.map((c) => [c, c, counts[c]])].forEach(([val, label, n]) => {
    const el = document.createElement("span");
    el.className = "chip" + (catFilter === val ? " on" : "");
    el.innerHTML = `${label.replace(/</g, "&lt;")}<b>${n}</b>`;
    el.onclick = () => { catFilter = val; renderChips(); renderList(); };
    box.appendChild(el);
  });
}

// case list
function renderList() {
  const q = $("search").value.trim().toLowerCase();
  const rows = SORTED.filter(
    (c) => (!catFilter || c.cat === catFilter) && (!q || c.name.toLowerCase().includes(q))
  );
  const list = $("list");
  list.innerHTML = "";
  if (!rows.length) {
    list.innerHTML = '<div class="empty">No cases match</div>';
    return;
  }
  const frag = document.createDocumentFragment();
  rows.forEach((c) => {
    const el = document.createElement("div");
    el.className = "item" + (picked && picked.id === c.id ? " sel" : "");
    el.title = `${c.name} (#${c.id})`;
    el.append(thumb(c, "thumb"), infoBlock(c), priceBlock(c));
    el.onclick = () => pick(c);
    frag.appendChild(el);
  });
  list.appendChild(frag);
}

function renderPicked() {
  const box = $("picked");
  box.innerHTML = "";
  if (!picked) {
    box.innerHTML = '<span class="none">No case picked - uses the page you\'re on</span>';
    return;
  }
  const x = document.createElement("button");
  x.id = "clear";
  x.title = "Clear";
  x.textContent = "✕";
  x.onclick = () => pick(null);
  box.append(thumb(picked, "thumb"), infoBlock(picked), priceBlock(picked), x);
}

function pick(c) {
  picked = c;
  chrome.storage.local.set({ lastCase: c ? c.id : "" });
  renderPicked();
  renderList();
  renderCost();
}

$("search").oninput = renderList;

// start / stop
$("toggle").onclick = async () => {
  const tab = await activeTab();
  if (!onSite(tab)) {
    setUi(false, "Open stridecsgo.net first");
    return;
  }
  if (active) {
    chrome.storage.local.remove("queue"); // a queue between two pages must stop too
    setUi(false, "Stopped");
    chrome.tabs.sendMessage(tab.id, { type: "stop" }).catch(() => {});
    return;
  }
  if (multi.length) return startQueue(tab);

  setCount($("count").value);
  const cfg = { maxOpens, delayMs: DELAY_MS };

  try {
    const target = picked ? `/cases/${picked.id}` : null;
    const here = new URL(tab.url).pathname.replace(/\/$/, "");
    if (target && here !== target) {
      // let the content script start once the page loads
      await chrome.storage.local.set({ pending: { id: picked.id, cfg, t: Date.now() } });
      await chrome.tabs.update(tab.id, { url: `https://stridecsgo.net${target}` });
      setUi(true, `Going to ${picked.name}...`, 0);
    } else {
      await ensureScript(tab);
      chrome.tabs.sendMessage(tab.id, { type: "start", cfg });
      setUi(true, "Starting...", 0);
    }
  } catch (e) {
    setUi(false, "Couldn't reach the page - refresh it and retry");
  }
};

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "status") return;
  const running = msg.state === "running";
  const word = running ? "Running" : msg.state === "done" ? "Done" : "Stopped";
  const q = msg.queue;
  if (q) {
    const done = q.before + (msg.opened || 0);
    setUi(
      running,
      `${word} · ${q.name} ${q.index + 1}/${q.total} · opened ${done} of ${q.grand}` +
        (!running && msg.reason ? ` (${msg.reason})` : ""),
      done,
      q.grand
    );
    return;
  }
  setUi(
    running,
    `${word} · opened ${msg.opened} of ${msg.max || maxOpens}` +
      (!running && msg.reason ? ` (${msg.reason})` : ""),
    msg.opened,
    msg.max
  );
});

// init
chrome.storage.local.get(["lastCase", "maxOpens", "multi", "queue"], (s) => {
  maxOpens = s.maxOpens > 0 ? s.maxOpens : 5;
  multi = (s.multi || []).filter((m) => caseById(m.id)).map((m) => ({ id: m.id, count: clampCount(m.count) }));
  $("count").value = maxOpens;
  renderPresets();
  renderMulti();
  renderCost();
  // a queue still running when the popup was reopened
  if (s.queue) {
    if (Date.now() - s.queue.t < QUEUE_FRESH_MS) setUi(true, "Queue running...");
    else chrome.storage.local.remove("queue");
  }
  picked = CASES.find((c) => c.id === s.lastCase) || null;
  // open on the last pick's category
  if (picked) catFilter = picked.cat;
  renderChips();
  renderPicked();
  renderList();
  const sel = document.querySelector(".item.sel");
  if (sel) sel.scrollIntoView({ block: "center" });
});


// quick sell tab
let sellActive = false;
let chosen = new Set();

function showTab(name) {
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.tab === name));
  ["open", "sell", "hits"].forEach((n) => ($("pane-" + n).hidden = name !== n));
  chrome.storage.local.set({ lastTab: name });
}
document.querySelectorAll(".tab").forEach((t) => (t.onclick = () => { showTab(t.dataset.tab); if (t.dataset.tab === "hits") autoScan(); }));

function renderRarities() {
  const box = $("rarities");
  box.innerHTML = "";
  RARITIES.forEach((r) => {
    const el = document.createElement("div");
    el.className = "rar" + (chosen.has(r.key) ? " on" : "");
    el.style.setProperty("--c", r.hex);
    el.innerHTML = '<span class="sw"></span><span class="n"></span><span class="box"></span>';
    el.children[1].textContent = r.name;
    el.onclick = () => {
      chosen.has(r.key) ? chosen.delete(r.key) : chosen.add(r.key);
      saveChosen();
    };
    box.appendChild(el);
  });
}
function saveChosen() {
  chrome.storage.local.set({ sellRarities: [...chosen] });
  renderRarities();
}
$("rAll").onclick = () => { chosen = new Set(RARITIES.map((r) => r.key)); saveChosen(); };
$("rNone").onclick = () => { chosen = new Set(); saveChosen(); };

function setSell(running, text, kind) {
  sellActive = running;
  $("sellGo").textContent = running ? "Stop" : "Start quick sell";
  $("sellGo").classList.toggle("stop", running);
  $("sellStatus").textContent = text;
  $("sellStatus").className = running ? "live" : kind === "err" ? "err" : "";
}

$("autoConfirm").onchange = () => chrome.storage.local.set({ sellAuto: $("autoConfirm").checked });

$("sellGo").onclick = async () => {
  const tab = await activeTab();
  if (!onSite(tab)) return setSell(false, "Open stridecsgo.net (your inventory) first", "err");
  if (sellActive) {
    chrome.tabs.sendMessage(tab.id, { type: "sellStop" });
    return;
  }
  if (!chosen.size) return setSell(false, "Pick at least one rarity", "err");
  try {
    await ensureScript(tab);
    chrome.tabs.sendMessage(tab.id, { type: "sell", rarities: [...chosen], autoConfirm: $("autoConfirm").checked });
    setSell(true, "Starting...");
  } catch (e) {
    setSell(false, "Couldn't reach the page - refresh it and retry", "err");
  }
};

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "sellStatus") return;
  setSell(msg.state === "running", msg.text, msg.state === "error" ? "err" : "");
});

chrome.storage.local.get(["sellRarities", "sellAuto", "lastTab"], (s) => {
  chosen = new Set(s.sellRarities || []);
  $("autoConfirm").checked = s.sellAuto === true;
  renderRarities();
  if (["sell", "hits"].includes(s.lastTab)) showTab(s.lastTab);
  if (s.lastTab === "hits") autoScan();
  // pick up a run already going
  activeTab().then((tab) => {
    if (!onSite(tab)) return;
    chrome.tabs.sendMessage(tab.id, { type: "getSellStatus" }, (r) => {
      if (chrome.runtime.lastError || !r) return;
      setSell(r.state === "running", r.text, r.state === "error" ? "err" : "");
    });
  });
});


// hits tab
function ago(t) {
  const s = Math.max(0, Math.round((Date.now() - t) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
const TYPE_LABEL = { knife: "Knife", gloves: "Gloves" };
function renderHits(h) {
  const box = $("hBox");
  box.innerHTML = "";
  // old data had two lists
  let items = h && (h.items || [...(h.knife || []), ...(h.gloves || [])].sort((a, b) => Number(b.id) - Number(a.id)));
  if (items) items = items.filter((i) => i && kgKind(i.name)); // knives / gloves only
  const lab = el("div", "hlabel");
  lab.append(el("span", "", "Latest knife / gloves"), el("span", "", items && items.length && h.t ? ago(h.t) : ""));
  box.appendChild(lab);
  if (!items || !items.length) {
    box.appendChild(el("div", "hempty", h ? "No knives or gloves found" : "Checking your inventory..."));
    return;
  }
  const a = items[0];
  const main = el("div", "hmain");
  main.style.setProperty("--c", a.color || "#eb4b4b");
  if (a.img) { const im = el("img"); im.src = a.img; im.alt = ""; main.appendChild(im); }
  const info = el("div", "hinfo");
  info.appendChild(el("div", "hname", (a.stattrak ? "StatTrak™ " : "") + a.name));
  const meta = el("div", "hmeta");
  if (a.wear) meta.appendChild(el("span", "", a.wear));
  if (Number(a.float) > 0) meta.appendChild(el("span", "", a.float));
  info.appendChild(meta);
  const tags = el("div", "htags");
  tags.appendChild(el("span", "htag", (TYPE_LABEL[a.type] || "Item").toUpperCase()));
  if (a.stattrak) tags.appendChild(el("span", "htag st", "ST"));
  if (a.pattern) tags.appendChild(el("span", "htag", a.pattern));
  if (a.tag) tags.appendChild(el("span", "htag", "“" + a.tag + "”"));
  if (a.locked) tags.appendChild(el("span", "htag", "LOCKED"));
  if (a.live) tags.appendChild(el("span", "htag", "JUST DROPPED"));
  info.appendChild(tags);
  main.appendChild(info);
  box.appendChild(main);
  const old = el("div", "hold");
  items.slice(1, 5).forEach((o) => {
    const r = el("div", "hrow");
    const left = el("span");
    left.append(el("span", "ty", TYPE_LABEL[o.type] || ""), document.createTextNode((o.stattrak ? "ST " : "") + o.name));
    r.append(left, el("span", "", (o.wear || "").replace(/[^A-Z]/g, "") || o.wear || ""));
    old.appendChild(r);
  });
  if (old.children.length) box.appendChild(old);
}
function setHitsStatus(text, kind) {
  $("hitsStatus").textContent = text;
  $("hitsStatus").className = kind === "live" ? "live" : kind === "err" ? "err" : "";
}
// refresh when the Hits tab opens (page script throttles it)
async function autoScan() {
  const tab = await activeTab();
  if (!onSite(tab)) return;
  try {
    await ensureScript(tab);
    chrome.tabs.sendMessage(tab.id, { type: "captureHits", auto: true });
  } catch (e) {}
}
$("hitsGo").onclick = async () => {
  const tab = await activeTab();
  if (!onSite(tab)) return setHitsStatus("Open stridecsgo.net first", "err");
  try {
    await ensureScript(tab);
    chrome.tabs.sendMessage(tab.id, { type: "captureHits" });
    setHitsStatus("Refreshing...", "live");
  } catch (e) {
    setHitsStatus("Couldn't reach the page - refresh it and retry", "err");
  }
};
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "hitsStatus") return;
  setHitsStatus(msg.text, msg.state === "running" ? "live" : msg.state === "error" ? "err" : "");
});
chrome.storage.onChanged.addListener((ch) => {
  if (ch.hits) renderHits(ch.hits.newValue);
});
chrome.storage.local.get("hits", (s) => {
  const h = s.hits || null;
  if (h && h.items && h.items.some((i) => !kgKind(i.name))) {
    h.items = h.items.filter((i) => kgKind(i.name)); // drop any weapon skins saved by older versions
    chrome.storage.local.set({ hits: h });
  }
  renderHits(h);
});
