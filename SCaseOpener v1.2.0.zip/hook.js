// runs in the page context (world MAIN) so it can read the site's responses
// looks at POST/PUT responses for knives/gloves (drops) and passes them to the extension via
// postMessage. it also reads the inventory API (v2/inventory/items) in the background for the
// hit scan. nothing leaves the browser
(() => {
  if (window.__csrHook) return;
  window.__csrHook = true;

  const KG = /(Knife|Karambit|Bayonet|Daggers|Gloves|Hand Wraps)/;
  const SKIP_URL = /(sell|lock|trade|market|store|withdraw|listing|craft|login|auth|chat|friend|match)/i;
  const kgOK = (v) => {
    const w = String(v).split("|")[0].replace(/^\s*\u2605\s*/, "").replace(/^StatTrak\u2122?\s*/i, "").replace(/\s*\([^)]*\)\s*$/, "").trim();
    return /(Gloves|Hand Wraps)$/i.test(w) || /(Knife|Karambit|Bayonet|Daggers)$/i.test(w);
  };
  const post = (d) => { try { window.postMessage({ __csr: true, ...d }, "*"); } catch (e) {} };

  const of = window.fetch;
  const API_ORIGIN = "https://api.stridecsgo.net";
  const WEARS = /^(Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)$/i;
  const WEAR_ABBR = /^(FN|MW|FT|WW|BS)$/;
  const PHASES = /^(Phase [1-4]|Ruby|Sapphire|Black Pearl|Emerald)$/i;
  const IMG_VAL = /\.(webp|png|jpe?g)(\?|$)|\/assets\//i;

  // flatten fields + nested objects, skip arrays (stickers etc)
  function flat(o, depth, out) {
    for (const [k, v] of Object.entries(o)) {
      if (v && typeof v === "object") {
        if (!Array.isArray(v) && depth < 3) flat(v, depth + 1, out);
      } else out.push([k, v]);
    }
    return out;
  }

  function normImg(v) {
    if (typeof v !== "string") return "";
    if (/^https?:/i.test(v)) return IMG_VAL.test(v) ? v : "";
    if (/^\/\//.test(v)) return "https:" + v;
    if (v.startsWith("/")) return IMG_VAL.test(v) ? API_ORIGIN + v : "";
    if (/^[0-9a-f]{32}$/i.test(v)) return `${API_ORIGIN}/v2/assets/items/${v}.webp`;
    if (/^[0-9a-f]{32}\.(webp|png)$/i.test(v)) return `${API_ORIGIN}/v2/assets/items/${v}`;
    return "";
  }

  function toItem(o) {
    const f = flat(o, 0, []);
    const nameEntry = f.find(([, v]) => typeof v === "string" && kgOK(v) && v.length < 90 && !/^https?:/i.test(v) && !IMG_VAL.test(v));
    if (!nameEntry) return null;
    let name = nameEntry[1].replace(/^★\s*/, "").trim();
    let wear = "";
    const w = name.match(/\s*\(([^)]+)\)\s*$/);
    if (w) { wear = w[1]; name = name.replace(w[0], ""); }
    const st = /StatTrak/i.test(name) || f.some(([k, v]) => /stat_?trak/i.test(k) && v === true);
    name = name.replace(/^StatTrak\u2122?\s*/i, "");
    if (!name.includes("|")) {
      const skin = f.find(([k, v]) => /skin|finish|pattern|paint/i.test(k) && typeof v === "string" && v.length < 40 && v !== name && !IMG_VAL.test(v));
      if (skin) name = name + " | " + skin[1];
    }
    if (!wear) {
      const e = f.find(([k, v]) => typeof v === "string" && (WEARS.test(v) || (WEAR_ABBR.test(v) && /wear|exterior|cond/i.test(k))));
      if (e) wear = e[1];
    }
    // real floats are never exactly 0 or 1
    const num = (v) => (typeof v === "number" ? v : typeof v === "string" && /^0\.\d+$/.test(v) ? parseFloat(v) : NaN);
    const good = (v) => v > 0 && v < 1;
    let fl = f.find(([k, v]) => /float|paint_?wear|wear_?value/i.test(k) && good(num(v)));
    if (!fl) fl = f.find(([k, v]) => /^wear$/i.test(k) && good(num(v)));
    // prefer image-looking keys
    let imgVal = "";
    for (const [k, v] of f) if (/image|icon|img|thumb|asset|picture|src|url/i.test(k) && normImg(v)) { imgVal = normImg(v); break; }
    if (!imgVal) for (const [, v] of f) if (typeof v === "string" && IMG_VAL.test(v) && normImg(v)) { imgVal = normImg(v); break; }
    const idEntry = f.find(([k, v]) => /^(id|item_?id|inventory_?id|inventory_item_?id|uid)$/i.test(k) && (typeof v === "number" || typeof v === "string"));
    const ph = f.find(([k, v]) => typeof v === "string" && (PHASES.test(v) || (/^(phase|pattern_?name|pattern)$/i.test(k) && v.length < 20)));
    const tag = f.find(([k, v]) => /name_?tag/i.test(k) && typeof v === "string" && v);
    return {
      id: idEntry ? String(idEntry[1]) : "",
      name,
      wear,
      stattrak: !!st,
      float: fl ? num(fl[1]).toFixed(6) : "",
      img: imgVal,
      pattern: ph ? ph[1] : "",
      tag: tag ? tag[1] : ""
    };
  }

  function collect(node, out, raws, depth) {
    if (!node || depth > 8 || out.length > 5) return;
    if (Array.isArray(node)) { node.forEach((n) => collect(n, out, raws, depth + 1)); return; }
    if (typeof node !== "object") return;
    const it = toItem(node);
    if (it) { out.push(it); raws.push(node); }
    for (const v of Object.values(node)) if (v && typeof v === "object") collect(v, out, raws, depth + 1);
  }

  function handle(method, url, text) {
    let path = url;
    try { path = new URL(url, location.href).pathname; } catch (e) {}
    if (SKIP_URL.test(path)) return;
    const found = [], raws = [];
    try { collect(JSON.parse(text), found, raws, 0); } catch (e) {}
    post({ kind: "api", method, path, found: found.length });
    // 1-2 items = a drop, a longer list is a catalogue
    if (found.length && found.length <= 2) {
      let raw = "";
      try { raw = JSON.stringify(raws, null, 1).slice(0, 4000); } catch (e) {}
      post({ kind: "drop", items: found, raw });
    }
  }


  // ---- inventory API (background hit scan, no page navigation) ----
  const INV_RE = /\/v2\/inventory\/items(\?|$)/;
  const INV_URL = API_ORIGIN + "/v2/inventory/items";
  const WEAR_FULL = { FN: "Factory New", MW: "Minimal Wear", FT: "Field-Tested", WW: "Well-Worn", BS: "Battle-Scarred" };
  let authHeaders = {}; // copied from the site's own calls to the API (kept in page memory only)

  function grabHeaders(h) {
    try {
      if (!h) return;
      const take = (k, v) => { if (/^authorization$/i.test(k)) authHeaders.Authorization = v; };
      if (typeof Headers !== "undefined" && h instanceof Headers) h.forEach((v, k) => take(k, v));
      else if (Array.isArray(h)) h.forEach(([k, v]) => take(k, v));
      else Object.keys(h).forEach((k) => take(k, h[k]));
    } catch (e) {}
  }

  function hitsFromInventory(j) {
    const defs = (j && j.defs) || {};
    const base = j.assetBaseUrl || API_ORIGIN + "/v2/assets/items/";
    const out = [];
    for (const i of j.items || []) {
      const d = defs[i.def];
      if (!d || (d.type !== "knife" && d.type !== "glove")) continue;
      const img = (i.wear && d.wearImages && d.wearImages[i.wear]) || d.image;
      const p0 = i.patterns && i.patterns[0];
      out.push({
        id: String(i.id),
        name: d.name,
        type: d.type === "glove" ? "gloves" : "knife",
        wear: WEAR_FULL[i.wear] || i.wear || "",
        stattrak: !!i.stattrak,
        float: typeof i.float === "number" && i.float > 0 && i.float < 1 ? i.float.toFixed(6) : "",
        pattern: (p0 && p0.label) || d.phase || "",
        tag: i.nametag || "",
        img: img ? base + img + ".webp" : "",
        color: (d.rarity && d.rarity.color) || "#eb4b4b",
        locked: !!i.protected
      });
    }
    out.sort((a, b) => Number(b.id) - Number(a.id));
    return out.slice(0, 6);
  }

  const reportInventory = (rid, text) => {
    try {
      const j = JSON.parse(text);
      if (!j || !Array.isArray(j.items) || !j.defs) return post({ kind: "inventoryHits", rid, error: "unexpected response" });
      post({ kind: "inventoryHits", rid, items: hitsFromInventory(j), truncated: !!j.truncated, total: j.total });
    } catch (e) { post({ kind: "inventoryHits", rid, error: "bad json" }); }
  };

  // content script asks for a background refresh
  window.addEventListener("message", async (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.__csrReq !== "inventory") return;
    try {
      const res = await of.call(window, INV_URL, { credentials: "include", headers: { Accept: "application/json", ...authHeaders } });
      if (!res.ok) return post({ kind: "inventoryHits", rid: d.rid, error: "HTTP " + res.status });
      reportInventory(d.rid, await res.text());
    } catch (err) {
      post({ kind: "inventoryHits", rid: d.rid, error: String((err && err.message) || err) });
    }
  });

  const wrap = (method) => /^(POST|PUT)$/i.test(method || "");

  if (of) {
    window.fetch = function (input, init) {
      const p = of.apply(this, arguments);
      try {
        const method = (init && init.method) || (input && input.method) || "GET";
        const url = typeof input === "string" ? input : (input && input.url) || String(input);
        const abs = (() => { try { return new URL(url, location.href); } catch (e) { return null; } })();
        if (abs && abs.origin === API_ORIGIN) { grabHeaders(init && init.headers); grabHeaders(input && typeof input === "object" && input.headers); }
        if (wrap(method)) p.then((res) => res.clone().text().then((t) => handle(method, url, t)).catch(() => {})).catch(() => {});
        else if (abs && INV_RE.test(abs.pathname + abs.search) && abs.origin === API_ORIGIN) p.then((res) => res.clone().text().then((t) => reportInventory("", t)).catch(() => {})).catch(() => {});
      } catch (e) {}
      return p;
    };
  }

  const xo = XMLHttpRequest.prototype.open;
  const xs = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__csr = { method, url };
    return xo.apply(this, arguments);
  };
  const xh = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    try { if (this.__csr && /^https:\/\/api\.stridecsgo\.net/i.test(new URL(this.__csr.url, location.href).href)) grabHeaders({ [k]: v }); } catch (e) {}
    return xh.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    try {
      if (this.__csr && !wrap(this.__csr.method)) {
        const u = new URL(this.__csr.url, location.href);
        if (u.origin === API_ORIGIN && INV_RE.test(u.pathname + u.search))
          this.addEventListener("load", () => { try { reportInventory("", this.responseText); } catch (e) {} });
      }
      if (this.__csr && wrap(this.__csr.method))
        this.addEventListener("load", () => {
          try { handle(this.__csr.method, this.__csr.url, this.responseText); } catch (e) {}
        });
    } catch (e) {}
    return xs.apply(this, arguments);
  };
})();
