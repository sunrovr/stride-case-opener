// content script: opens cases, quick sells, tracks hits
// opens by clicking "Open 5 more" when it's there, otherwise "Open <price>"
// stops at the limit, on Esc, or when there's no button

if (!window.__csrOpenerLoaded) {
  window.__csrOpenerLoaded = true;

  let running = false;
  let opened = 0;
  let maxOpens = 0;
  let queueCtx = null; // {index, total, name, before, grand} while a multi-case queue runs
  const QUEUE_FRESH_MS = 60 * 1000; // a queue older than this (no progress) is dropped

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const jitter = (ms) => ms; // exact delay, no randomness
  const norm = (el) => (el.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
  const usable = (el) =>
    el.offsetParent !== null && !el.disabled && el.getAttribute("aria-disabled") !== "true";

  function findButton() {
    const buttons = [...document.querySelectorAll("button, [role='button']")].filter(usable);
    // "Open 5 more" + coin price, e.g. "open 5 more2,675"
    const more = buttons.find((b) => /^open\s*5\s*more/.test(norm(b)));
    if (more) return more;
    // "Open" + coin price, e.g. "open2,675"
    return buttons.find((b) => /^open\s*[\d,.]*$/.test(norm(b)));
  }

  function report(state, reason) {
    try {
      chrome.runtime.sendMessage({ type: "status", state, opened, reason, max: maxOpens, queue: queueCtx });
    } catch (e) {}
    if (queueCtx) {
      // keep the stored queue fresh while it runs, so a reopened popup sees it is still going
      chrome.storage.local.get("queue").then(({ queue }) => {
        if (queue && queueCtx) chrome.storage.local.set({ queue: { ...queue, t: Date.now() } });
      }).catch(() => {});
    }
  }


  // site says this when it can't add more
  function inventoryFull() {
    return /inventory is full/i.test(document.body.innerText || "");
  }

  // opens one case's batch. resolves to why it stopped:
  // "limit" (opened all it was asked), "stopped", "inventory", "nobutton"
  async function runInner(cfg) {
    if (running) return "busy";
    running = true;
    opened = 0;
    maxOpens = cfg.maxOpens;
    report("running");
    let misses = 0;

    // give the page a sec to draw its buttons
    if (cfg.waitForButton) {
      for (let i = 0; i < 40 && running && !findButton(); i++) await sleep(500);
    }

    while (running && opened < cfg.maxOpens) {
      if (inventoryFull()) {
        report("stopped", "Inventory is full");
        running = false;
        return "inventory";
      }
      const btn = findButton();
      if (!btn) {
        if (++misses >= 6) {
          report("stopped", "No Open button found (out of coins, or not on a case page)");
          running = false;
          return "nobutton";
        }
        await sleep(700);
        continue;
      }
      misses = 0;
      btn.click();
      opened++;
      report("running");
      await sleep(jitter(cfg.delayMs));
      if (running && inventoryFull()) {
        report("stopped", "Inventory is full");
        running = false;
        return "inventory";
      }
    }

    if (running) {
      running = false;
      return "limit";
    }
    return "stopped";
  }

  let liveSeen = false; // a knife / gloves dropped during the current run
  async function run(cfg) {
    if (running) return;
    liveSeen = false;
    const why = await runInner(cfg);
    if (why === "limit" && !queueCtx) report("done", "Reached limit");
    // if a knife/gloves dropped, go grab the real item info
    setTimeout(() => autoCapture(liveSeen, liveSeen), 2500);
    return why;
  }

  // ---- multi-case queue: opens each case in turn, moving to the next page itself ----
  async function cancelQueue() {
    queueCtx = null;
    try { await chrome.storage.local.remove("queue"); } catch (e) {}
  }

  async function queueStep() {
    if (running || selling) return;
    let q;
    try { q = (await chrome.storage.local.get("queue")).queue; } catch (e) { return; }
    if (!q || !q.items || !q.items[q.index]) return;
    const item = q.items[q.index];
    if (location.pathname.replace(/\/$/, "") !== `/cases/${item.id}`) return;
    if (Date.now() - q.t > QUEUE_FRESH_MS) return cancelQueue();

    const total = q.items.length;
    const grand = q.items.reduce((s, i) => s + i.count, 0);
    const before = q.items.slice(0, q.index).reduce((s, i) => s + i.count, 0);
    queueCtx = { index: q.index, total, name: item.name, before, grand };
    const why = await run({ maxOpens: item.count, delayMs: q.delayMs, waitForButton: true });

    if (why !== "limit") return cancelQueue(); // stopped, inventory full or no button: the queue ends
    if (q.index + 1 < total) {
      await chrome.storage.local.set({ queue: { ...q, index: q.index + 1, t: Date.now() } });
      await sleep(3000); // let the knife/gloves check finish before the page changes
      const { queue: still } = await chrome.storage.local.get("queue");
      if (!still) return; // stopped during the pause
      location.href = `https://stridecsgo.net/cases/${q.items[q.index + 1].id}`;
    } else {
      report("done", null);
      cancelQueue();
    }
  }

  // case links for the popup list
  function listCases() {
    const found = new Map();
    document.querySelectorAll("a[href]").forEach((a) => {
      const m = (a.getAttribute("href") || "").match(/\/cases\/(\d+)\/?(?:[?#].*)?$/);
      if (!m || found.has(m[1])) return;
      const lines = (a.innerText || "").split("\n").map((s) => s.trim()).filter(Boolean);
      const name = a.getAttribute("aria-label") || lines.find((t) => /[a-z]/i.test(t)) || `Case ${m[1]}`;
      found.set(m[1], name.slice(0, 40));
    });
    return [...found].map(([id, name]) => ({ id, name }));
  }


  // ---- quick sell ----
  let selling = false;
  let sellState = { state: "idle", text: "" };

  function sellReport(state, text) {
    sellState = { state, text };
    try { chrome.runtime.sendMessage({ type: "sellStatus", state, text }); } catch (e) {}
  }

  const visible = (el) => !!el && el.offsetParent !== null;

  function hexToRgb(h) {
    h = h.trim().replace("#", "");
    if (h.length === 3) h = h.split("").map((x) => x + x).join("");
    const n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function parseColor(v) {
    v = (v || "").trim();
    if (!v) return null;
    if (v[0] === "#") return hexToRgb(v);
    const m = v.match(/(\d+)[,\s]+(\d+)[,\s]+(\d+)/);
    return m ? [+m[1], +m[2], +m[3]] : null;
  }
  function rarityKey(card) {
    let v = getComputedStyle(card).getPropertyValue("--rarity");
    if (!v) v = ((card.getAttribute("style") || "").match(/--rarity:\s*([^;]+)/) || [])[1];
    const rgb = parseColor(v);
    if (!rgb) return null;
    let best = null, bestD = Infinity;
    for (const r of RARITIES) {
      const c = hexToRgb(r.hex);
      const d = Math.hypot(c[0] - rgb[0], c[1] - rgb[1], c[2] - rgb[2]);
      if (d < bestD) { bestD = d; best = r.key; }
    }
    return bestD <= 70 ? best : null;
  }

  // padlock says "Unlock item" when it's locked
  function isLocked(li) {
    return !!li.querySelector(
      '[aria-label="Unlock item"], [title="Unlock item"], button[aria-label*="unlock" i][aria-pressed="true"], [style*="lock-fill"]'
    );
  }

  function cardOf(li) {
    return li.querySelector("button[data-item-id]");
  }
  function tickTarget(li, card) {
    return li.querySelector('input[type="checkbox"], [role="checkbox"]') || card;
  }
  function looksSelected(li, card) {
    const t = tickTarget(li, card);
    return (
      t.checked === true ||
      ["aria-checked", "aria-pressed", "aria-selected"].some((a) => t.getAttribute(a) === "true") ||
      card.getAttribute("data-selected") === "true"
    );
  }

  function findSellToggle() {
    return [...document.querySelectorAll("button[aria-pressed]")].find((b) => norm(b) === "quick sell");
  }

  function findConfirmBtn() {
    return [...document.querySelectorAll("button")].find((b) => visible(b) && norm(b) === "sell all");
  }
  function confirmRoot(btn) {
    let n = btn;
    for (let i = 0; i < 10 && n; i++, n = n.parentElement) {
      if (/you receive/i.test(n.textContent || "")) return n;
    }
    return btn.closest('[role="dialog"]') || btn.parentElement;
  }

  function getScroller(ul) {
    let el = ul.parentElement;
    while (el && el !== document.body && el !== document.documentElement) {
      const s = getComputedStyle(el);
      if (/(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight + 10) return el;
      el = el.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  const ALIASES = {
    consumer: /consumer/, industrial: /industrial/, milspec: /mil-?\s?spec/,
    restricted: /restricted/, classified: /classified/, covert: /covert/, contraband: /contraband/
  };

  async function waitFor(fn, tries = 30, ms = 100) {
    for (let i = 0; i < tries; i++) {
      const r = fn();
      if (r) return r;
      await sleep(ms);
    }
    return null;
  }

  const findByText = (text, extra = () => true) =>
    [...document.querySelectorAll("button")].find((b) => visible(b) && norm(b) === text && extra(b));

  // blue quick sell button after selecting stuff (no aria-pressed, unlike the toggle)
  function findSellOpener() {
    const all = [...document.querySelectorAll("button")].filter((b) => visible(b) && !b.disabled && b.getAttribute("aria-disabled") !== "true" && norm(b) === "quick sell");
    return (
      all.find((b) => !b.hasAttribute("aria-pressed")) ||
      all.find((b) => /from-blue-500/.test(b.className)) ||
      null
    );
  }

  // counts unlocked cards of the chosen rarities, no clicking
  async function scanList(want, sc) {
    const seen = new Set();
    const out = { expected: 0, locked: 0, other: 0, total: 0 };
    sc.scrollTop = 0;
    await sleep(400);
    const step = Math.max(300, Math.round(window.innerHeight * 0.6));
    for (let guard = 0; selling && guard < 400; guard++) {
      const ul = document.querySelector('ul[aria-label="Items"]');
      if (!ul) break;
      for (const li of ul.querySelectorAll(":scope > li")) {
        const card = cardOf(li);
        if (!card) continue;
        const id = card.getAttribute("data-item-id");
        if (seen.has(id)) continue;
        seen.add(id);
        out.total++;
        const rk = rarityKey(card);
        const match = rk && want.has(rk);
        if (!match) out.other++;
        else if (isLocked(li)) out.locked++;
        else out.expected++;
      }
      sellReport("running", `Scanning inventory... ${out.total} items checked`);
      if (sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4) break;
      sc.scrollTop += step;
      await sleep(240);
    }
    sc.scrollTop = 0;
    await sleep(300);
    return out;
  }

  // use the Filters panel to show only the chosen rarities
  async function applyRarityFilter(want) {
    const fbtn = [...document.querySelectorAll("button")].find((b) => visible(b) && /^filters/.test(norm(b)));
    if (!fbtn) return false;
    fbtn.click();
    await sleep(600);
    const root = document.querySelector('[role="dialog"]') || document.body;

    // reset first if there's a clear button
    const reset = [...root.querySelectorAll("button")].find((b) => visible(b) && /^(clear|reset)( all| filters)?$/.test(norm(b)));
    if (reset) { reset.click(); await sleep(300); }

    const clickable = "button, label, [role=checkbox], [role=option], [role=menuitemcheckbox], [role=switch], li";
    let clicked = 0;
    for (const r of RARITIES) {
      if (!want.has(r.key)) continue;
      const re = ALIASES[r.key];
      const els = [...root.querySelectorAll(clickable)].filter((e) => visible(e) && re.test(norm(e)) && norm(e).length < 40);
      if (!els.length) continue;
      // smallest match is the real option, not a wrapper
      els.sort((a, b) => a.querySelectorAll("*").length - b.querySelectorAll("*").length);
      els[0].click();
      clicked++;
      await sleep(250);
    }
    if (!clicked) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      return false;
    }

    const done = [...root.querySelectorAll("button")].find((b) => visible(b) && /^(apply|done|show|close|save|show results|show \d.*|apply filters)$/.test(norm(b)));
    if (done) done.click();
    else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    await sleep(700);
    return true;
  }

  // go through the sidebar link so the page doesn't reload
  async function goToPage(name) {
    const re = new RegExp("^/" + name + "/?$", "i");
    const link = [...document.querySelectorAll("a[href]")].find(
      (a) => re.test(a.getAttribute("href") || "") || (visible(a) && norm(a) === name)
    );
    if (!link) return false;
    link.click();
    return true;
  }

  async function runSell(cfg) {
    if (selling) return;
    selling = true;
    const want = new Set(cfg.rarities);
    const names = RARITIES.filter((r) => want.has(r.key)).map((r) => r.name).join(", ");
    const fail = (t) => { sellReport("error", t); selling = false; };

    try {
      document.getElementById("inventory-tab-all")?.click();
      await sleep(300);

      let ul = document.querySelector('ul[aria-label="Items"]');
      if (!ul) {
        sellReport("running", "Going to Inventory...");
        if (!(await goToPage("inventory"))) return fail("Couldn't find the Inventory link - open your inventory first");
        ul = await waitFor(() => {
          const u = document.querySelector('ul[aria-label="Items"]');
          return u && u.querySelector(":scope > li") ? u : null;
        }, 100, 100);
        if (!ul) return fail("Inventory didn't load");
        await sleep(400);
      }

      // filter first
      sellReport("running", `Filtering to ${names}...`);
      const filtered = await applyRarityFilter(want);
      if (!filtered) return fail("Couldn't find the rarity filters - open your inventory and try again");
      if (!selling) return;

      // what's on screen right now
      const lookAt = () => {
        const u = document.querySelector('ul[aria-label="Items"]');
        const lis = u ? [...u.querySelectorAll(":scope > li")].filter((li) => cardOf(li)) : [];
        let lockedVisible = 0, wrong = false;
        for (const li of lis) {
          const card = cardOf(li);
          if (!card) continue;
          const rk = rarityKey(card);
          if (!(rk && want.has(rk))) wrong = true;
          if (isLocked(li)) lockedVisible++;
        }
        return { u, count: lis.length, wrong, lockedVisible, shown: parseInt(u && u.getAttribute("data-total"), 10) || 0 };
      };

      // site caps a sale around 200, so loop until nothing's left
      let totalSold = 0, batches = 0, batch = 0, lastShown = Infinity, onlyLockedLeft = false;
      while (selling && batch < 200) {
        batch++;
        let v = lookAt();
        if (!v.u) { if (totalSold) break; return fail("Item grid disappeared"); }
        if (!v.count) break; // nothing left in this rarity
        if (v.wrong && batch > 1) {
          // filter got reset after the sale, redo it
          await applyRarityFilter(want);
          await sleep(500);
          v = lookAt();
          if (!v.count) break;
        }
        if (v.wrong) return fail("Rarity filter didn't apply (other rarities still shown) - nothing selected");
        if (v.shown && v.shown >= lastShown) return fail("The list didn't shrink after selling - stopped to be safe");
        lastShown = v.shown || lastShown;

        // quick sell on
        const toggle = findSellToggle();
        if (!toggle) return fail('Couldn\'t find the "Quick sell" button');
        if (toggle.getAttribute("aria-pressed") !== "true") {
          toggle.click();
          await sleep(500);
        }

        // select all
        sellReport("running", (batch > 1 ? `Batch ${batch} · ${totalSold} sold · ` : "") + "Selecting all shown...");
        const selAll = await waitFor(() => findByText("select all shown"), 30, 100);
        if (!selAll) return fail('Couldn\'t find the "Select all shown" button');
        selAll.click();
        await sleep(600);

        // blue button opens the confirm window
        const opener = await waitFor(findSellOpener, 30, 100);
        if (!opener) {
          if (batch > 1) { onlyLockedLeft = true; break; } // nothing selectable left (only locked items)
          return fail('Selected, but couldn\'t find the blue "Quick sell" button');
        }
        opener.click();
        const confirm = await waitFor(findConfirmBtn, 40, 100);
        if (!confirm) return fail('The "Sell all" window never appeared');

        // sanity check
        const root = confirmRoot(confirm);
        const m = (root.textContent || "").match(/(\d[\d,]*)\s*items?/i);
        const inWindow = m ? parseInt(m[1].replace(/,/g, ""), 10) : null;
        if (!inWindow) {
          if (totalSold) {
            // nothing selected, only locked stuff left
            const cancel = [...document.querySelectorAll("button")].find((x) => visible(x) && norm(x) === "cancel");
            if (cancel) cancel.click();
            onlyLockedLeft = true;
            break;
          }
          return fail("Couldn't read the item count in the Sell all window - NOT sold");
        }
        // everything selected while a locked card is showing means it grabbed locked ones
        if (v.lockedVisible && v.shown && inWindow >= v.shown)
          return fail("Select all also picked up locked items - NOT sold. Check the window, then Cancel.");

        // auto-confirm off: leave the site's window open
        if (!cfg.autoConfirm) {
          sellReport("done", `${inWindow} items ready - press "Sell all" on the site to confirm`);
          selling = false;
          return;
        }

        // confirm, wait for the list to refresh
        confirm.click();
        await waitFor(() => !findConfirmBtn(), 60, 100);
        totalSold += inWindow;
        batches++;
        sellReport("running", `Sold ${totalSold} so far (batch ${batch})...`);
        await waitFor(() => {
          const u = document.querySelector('ul[aria-label="Items"]');
          return !u || !u.querySelector(":scope > li") || (parseInt(u.getAttribute("data-total"), 10) || 0) < lastShown;
        }, 50, 100);
        await sleep(700);
      }

      if (!selling) return;
      if (!totalSold) return fail(`No unlocked ${names} items to sell`);
      sellReport("done", `Sold ${totalSold} ${names} items in ${batches} batch${batches > 1 ? "es" : ""}` + (onlyLockedLeft ? " · nothing else sellable (locked items left)" : ""));
      selling = false;
    } catch (e) {
      fail("Error: " + (e && e.message ? e.message : e));
    }
  }



  // ---- hits (latest knife / gloves) ----
  // from hook.js drops, the inventory page, or a full scan
  const hitsReport = (state, text) => {
    try { chrome.runtime.sendMessage({ type: "hitsStatus", state, text }); } catch (e) {}
  };
  const KG_RE = /(Knife|Karambit|Bayonet|Daggers|Gloves|Hand Wraps)/;
  const kgType = (name) => kgKind(name);
  const getHits = () => new Promise((r) => chrome.storage.local.get("hits", (s) => r(s.hits || null)));
  const setHits = (h) => { if (h && h.items) h.items = h.items.filter((i) => i && kgKind(i.name)); return new Promise((r) => chrome.storage.local.set({ hits: h }, r)); };

  function setSelectValue(sel, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value").set;
    setter.call(sel, value);
    sel.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function readCardInfo(li) {
    const card = cardOf(li);
    if (!card) return null;
    const label = card.getAttribute("aria-label") || "";
    const cut = label.lastIndexOf(", ");
    const full = cut > 0 ? label.slice(0, cut) : label;
    const wear = cut > 0 ? label.slice(cut + 2) : "";
    const st = /^StatTrak/i.test(full);
    const name = full.replace(/^StatTrak\u2122?\s*/i, "");
    const rv = (card.getAttribute("style") || "").match(/--rarity:\s*([^;]+)/);
    return {
      id: card.getAttribute("data-item-id"),
      name,
      type: kgType(name),
      wear,
      stattrak: st,
      float: (li.querySelector(".font-num") || {}).textContent || "",
      pattern: (li.querySelector(".pattern-badge") || { getAttribute: () => "" }).getAttribute("title") || "",
      tag: ((li.querySelector('[title^="Name tag"]') || { getAttribute: () => "" }).getAttribute("title") || "").replace(/^Name tag:\s*/, ""),
      img: (card.querySelector("img") || {}).src || "",
      color: rv ? rv[1].trim() : "#eb4b4b",
      locked: isLocked(li)
    };
  }

  const realMaxId = (items) => Math.max(0, ...(items || []).filter((i) => !i.live && /^\d+$/.test(i.id || "")).map((i) => Number(i.id)));

  // inventory page: pick up anything newer than what we have
  let passiveTimer = null;
  async function passiveInventory() {
    if (running || selling) return;
    const ul = document.querySelector('ul[aria-label="Items"]');
    if (!ul) return;
    const h = await getHits();
    if (!h || !h.items || !h.items.some((i) => !i.live)) return; // needs one real scan first, otherwise "newest" is unknown
    const max = realMaxId(h.items);
    const fresh = [...ul.querySelectorAll(":scope > li")]
      .map(readCardInfo)
      .filter((i) => i && i.type && /^\d+$/.test(i.id || "") && Number(i.id) > max);
    if (!fresh.length) return;
    const have = new Set(h.items.map((i) => i.id));
    const merged = [...fresh.filter((i) => !have.has(i.id)), ...h.items.filter((i) => !i.live)]
      .sort((a, b) => Number(b.id) - Number(a.id))
      .slice(0, 6);
    await setHits({ items: merged, t: Date.now() });
    hitsReport("done", `New ${merged[0].type === "gloves" ? "gloves" : "knife"}: ${merged[0].name}`);
  }
  new MutationObserver(() => {
    clearTimeout(passiveTimer);
    passiveTimer = setTimeout(passiveInventory, 600);
  }).observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(passiveInventory, 1500);
  setTimeout(() => autoCapture(false), 2500); // already on Inventory? read it now (no navigation)

  // live drops from hook.js
  window.addEventListener("message", async (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.__csr !== true) return;
    if (d.kind === "api") {
      chrome.storage.local.set({ lastApi: { method: d.method, path: d.path, found: d.found, t: Date.now() } });
      return;
    }
    if (d.kind === "inventoryHits") {
      const w = d.rid && apiWaiters.get(d.rid);
      if (w) w(d);
      else if (!d.error && !d.truncated && Array.isArray(d.items)) applyApiHits(d.items); // site loaded its inventory, free refresh
      return;
    }
    if (d.kind !== "drop" || !Array.isArray(d.items)) return;
    chrome.storage.local.set({ lastDrop: { raw: d.raw || "", t: Date.now() } });
    const h = (await getHits()) || { items: [] };
    for (const it of d.items) {
      const type = kgType(it.name);
      if (!type) continue;
      const entry = { ...it, type, live: true, color: "#eb4b4b", id: it.id || "live-" + Date.now() };
      // keep the earlier copy if we already have it
      const prev = h.items.find((x) => x.id === entry.id);
      if (prev) continue;
      if (h.items.some((x) => x.id === entry.id)) continue;
      h.items.unshift(entry);
      if (running) liveSeen = true;
      else setTimeout(() => autoCapture(true, true), 3000);
      hitsReport("done", `Detected ${type === "gloves" ? "gloves" : "a knife"}: ${entry.name}`);
    }
    h.items = h.items.slice(0, 6);
    h.t = Date.now();
    await setHits(h);
  });

  // ---- background scan via the inventory API (hook.js does the request, no navigation) ----
  const apiWaiters = new Map();
  function fetchHitsApi(timeout = 8000) {
    return new Promise((resolve) => {
      const rid = "r" + Date.now() + Math.random().toString(36).slice(2, 6);
      const t = setTimeout(() => { apiWaiters.delete(rid); resolve({ error: "timeout" }); }, timeout);
      apiWaiters.set(rid, (d) => { clearTimeout(t); apiWaiters.delete(rid); resolve(d); });
      window.postMessage({ __csrReq: "inventory", rid }, "*");
    });
  }
  async function applyApiHits(items) {
    const all = (items || []).filter((i) => i && kgKind(i.name)).slice(0, 6);
    await setHits({ items: all, t: Date.now() });
    chrome.storage.local.set({ hitsScanT: Date.now() });
    hitsReport("done", all.length ? `Updated · latest: ${all[0].name}` : "No knives or gloves found");
  }

  // auto scan, throttled. only navigates when allowed
  const AUTO_MIN_MS = 90 * 1000;
  async function autoCapture(navigate, force) {
    if (running || selling) return;
    const { hitsScanT } = await new Promise((r) => chrome.storage.local.get("hitsScanT", r));
    if (!force && hitsScanT && Date.now() - hitsScanT < AUTO_MIN_MS) return;
    captureHits(!!navigate);
  }

  // full scan: inventory API first, falls back to the Knifes / Gloves tabs
  async function captureHits(allowNavigate) {
    if (running || selling) return hitsReport("error", "Busy - stop the opener / sell first");
    try {
      // 1) background: ask the inventory API, works from any page, no navigation
      const api = await fetchHitsApi();
      if (api && !api.error && !api.truncated && Array.isArray(api.items)) return applyApiHits(api.items);
      // 2) fallback: read the Inventory page (list was cut off or the API call failed)
      let ul = document.querySelector('ul[aria-label="Items"]');
      if (!ul) {
        if (!allowNavigate) return;
        hitsReport("running", "Going to Inventory...");
        if (!(await goToPage("inventory"))) return hitsReport("error", "Couldn't find the Inventory link");
        ul = await waitFor(() => {
          const u = document.querySelector('ul[aria-label="Items"]');
          return u && u.querySelector(":scope > li") ? u : null;
        }, 100, 100);
        if (!ul) return hitsReport("error", "Inventory didn't load");
        await sleep(400);
      }
      const sortSel = [...document.querySelectorAll("select")].find((s) => [...s.options].some((o) => o.value === "newest"));
      const prevSort = sortSel ? sortSel.value : null;
      if (sortSel && prevSort !== "newest") { setSelectValue(sortSel, "newest"); await sleep(500); }

      let all = [];
      for (const [key, tabId] of [["knife", "inventory-tab-knives"], ["gloves", "inventory-tab-gloves"]]) {
        hitsReport("running", `Reading ${key === "knife" ? "knives" : "gloves"}...`);
        const tab = document.getElementById(tabId);
        if (!tab) continue;
        tab.click();
        await sleep(900);
        const u = document.querySelector('ul[aria-label="Items"]');
        const items = u ? [...u.querySelectorAll(":scope > li")].map(readCardInfo).filter(Boolean) : [];
        // tab might not have filtered yet, so keep only real knives/gloves (newest 5)
        const only = items.filter((i) => i.type === key);
        all = all.concat(only.sort((a, b) => Number(b.id) - Number(a.id)).slice(0, 5));
      }
      document.getElementById("inventory-tab-all")?.click();
      if (sortSel && prevSort && prevSort !== "newest") { await sleep(300); setSelectValue(sortSel, prevSort); }
      all.sort((a, b) => Number(b.id) - Number(a.id));
      await setHits({ items: all.slice(0, 6), t: Date.now() });
      chrome.storage.local.set({ hitsScanT: Date.now() });
      hitsReport("done", all.length ? `Updated · latest: ${all[0].name}` : "No knives or gloves found");
    } catch (e) {
      hitsReport("error", "Error: " + (e && e.message ? e.message : e));
    }
  }

  // popup sent us here to open a case
  chrome.storage.local.get("pending", ({ pending }) => {
    if (!pending) return;
    chrome.storage.local.remove("pending");
    if (Date.now() - pending.t > 60000) return;
    if (location.pathname.replace(/\/$/, "") === `/cases/${pending.id}`) {
      run({ ...pending.cfg, waitForButton: true });
    }
  });

  queueStep(); // continue a queue after moving to the next case

  chrome.runtime.onMessage.addListener((msg, _s, send) => {
    if (msg.type === "listCases") send(listCases());
    if (msg.type === "start") run(msg.cfg);
    if (msg.type === "queueStart") queueStep();
    if (msg.type === "stop" && (running || queueCtx)) {
      running = false;
      cancelQueue();
      report("stopped", "Stopped");
    }
    if (msg.type === "ping") send({ ok: true });
    if (msg.type === "sell") runSell(msg);
    if (msg.type === "sellStop" && selling) {
      selling = false;
      sellReport("stopped", "Stopped");
    }
    if (msg.type === "getSellStatus") send(sellState);
    if (msg.type === "captureHits") (msg.auto ? autoCapture(true) : captureHits(true));
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && (running || queueCtx)) {
      running = false;
      cancelQueue();
      report("stopped", "Esc pressed");
    }
    if (e.isTrusted && e.key === "Escape" && selling) {
      selling = false;
      sellReport("stopped", "Esc pressed");
    }
  });
}
