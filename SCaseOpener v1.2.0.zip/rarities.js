// Shared rarity palette (popup + content script). Matching is by nearest colour,
// so tiny colour differences on the site still resolve to the right rarity.
var RARITIES = [
  { key: "consumer",   name: "Consumer",   hex: "#b0c3d9" },
  { key: "industrial", name: "Industrial", hex: "#5e98d9" },
  { key: "milspec",    name: "Mil-Spec",   hex: "#4b69ff" },
  { key: "restricted", name: "Restricted", hex: "#8847ff" },
  { key: "classified", name: "Classified", hex: "#d32ce6" },
  { key: "covert",     name: "Covert",     hex: "#eb4b4b" },
  { key: "contraband", name: "Contraband", hex: "#e4ae39" }
];

// Knife / gloves test used by the popup and content script. Only the weapon part of the name
// (before " | ") is checked, so a skin like "AK-47 | ..." can never match by accident.
var kgKind = function (name) {
  var w = String(name || "").split("|")[0].replace(/^\s*\u2605\s*/, "").replace(/^StatTrak\u2122?\s*/i, "").replace(/\s*\([^)]*\)\s*$/, "").trim();
  if (/(Gloves|Hand Wraps)$/i.test(w)) return "gloves";
  if (/(Knife|Karambit|Bayonet|Daggers)$/i.test(w)) return "knife";
  return null;
};
